<p align="center"><img src="docs/logo.png" alt="Motus" width="420"></p>

# Motus

Motus is a one-dimensional seismic site response program written in Rust. It covers the workflow of D-MOD2000 and SHAKE2000: build a horizontally layered soil column over an elastic half-space, choose modulus-reduction and damping curves, apply an input motion, and compare linear, equivalent-linear and nonlinear effective-stress results. The interface follows the Photoshop-style layout of [PhotoCraft](https://github.com/storytold/photocraft), whose theme tokens, dock cards and buttons are ported in `app/src/theme.rs` and `app/src/widgets.rs`.

![Results](docs/results_profiles.png)

## Methods

The frequency-domain solver (`core/src/analysis.rs`) propagates vertically incident SH waves through the column with complex moduli G* = G(1 − 2D² + 2iD√(1 − D²)), as in SHAKE91, and treats the input as an outcrop motion over an elastic half-space or as a within motion at a rigid base. The equivalent-linear option iterates strain-compatible G and D from an effective strain of 0.65 γmax until both change by less than the tolerance, and the final pass recomputes the response with the converged properties so strains and properties stay consistent.

The time-domain solver (`core/src/nonlinear.rs`) discretises the column into a lumped-mass shear beam whose sublayers are no thicker than Vs/(ppw·fmax), which is the D-MOD rule h < Vs/100 at fmax = 25 Hz and four points per wavelength. Each sublayer follows an MKZ backbone with extended Masing unload-reload rules and loop memory, and the Phillips & Hashash (2009) reduction factor can scale every loop so the hysteretic damping matches the target curve instead of the Masing value. Viscous damping is Rayleigh type, either simplified (D-MOD n = 0) or exact at the first mode and a chosen higher mode, and the elastic base is a Lysmer dashpot that is driven by the outcrop velocity. Newmark average acceleration with full Newton iterations solves each step, and the tridiagonal-plus-one-column Jacobian is factorised with the Thomas algorithm and the Sherman-Morrison formula.

Sands that generate pore pressure use the Dobry et al. (1985) and Matasovic (1993) model. Each strain reversal closes a half-cycle that adds half an equivalent cycle at its amplitude, and the excess pore pressure ratio degrades the backbone as Gmo* = Gmo√(1 − ru) and γr* = γr√(1 − ru). Clays follow Matasovic & Vucetic (1995) instead: the degradation index δ = N^(−t), with t = s(γc − γtv)^r, scales the backbone stress as in Idriss et al. (1978), and the pore-pressure ratio is ur = Aδ³ + Bδ² + Cδ + D with D = −(A + B + C), so ur is zero before the clay degrades. The default clay and sand parameters are placeholders that must be calibrated against cyclic tests on the soil in question.

Excess pore pressure redistributes and dissipates through the saturated column by the Martin et al. (1975) equation ∂u/∂t = (Er/γw) ∂/∂z(k ∂u/∂z) + ∂ug/∂t, with the rebound modulus Er = σ'v^(1−m)/(m Kr σ'v0^(n−m)) and each layer's hydraulic conductivity k (`core/src/pwp.rs`). The equation is solved with an explicit finite-volume scheme on the sublayers, which uses series conductances between neighbours, treats the water table as a drained boundary and the base as drained or impervious, and sub-steps automatically to stay stable. Dissipation runs during shaking and, optionally, for a set time after the record, so the pore pressure that a low-permeability clay traps above a liquefied sand stays visible in the results.

Viscous damping in the time domain is Rayleigh type (simplified or two-frequency) or frequency independent, $C = M^{1/2}\Phi\,\mathrm{diag}(2\zeta\omega)\,\Phi^T M^{1/2}$ from the modes of the column, which gives every mode the same damping ratio as the frequency-domain solution. Layers with a shear strength get a GQ/H backbone (Groholski et al. 2016) fitted to the strength-corrected curve, so the nonlinear stress never exceeds the strength.

Curves come from Darendeli (2001) and Menq (2003), both evaluated at the mean effective stress of each sublayer, from a user MKZ backbone with Masing damping, from a user table to which an MKZ backbone is fitted, or from a library of 30 published curves (Vucetic & Dobry 1991, EPRI 1993, Seed & Idriss, Idriss 1990, GEI 1983, GeoMatrix 1990 and others) converted from pystrata's `published_curves.toml` (MIT). Motions are read from PEER NGA `.AT2` files or plain columns, or generated with Boore's (2003) stochastic point-source method. The generator applies a zero-phase 0.1 Hz Butterworth high-pass filter and a polynomial baseline correction, so the record has no residual velocity. Response spectra use the exact piecewise-linear solution of Nigam & Jennings (1969), and Fourier spectra can be smoothed with the Konno-Ohmachi (1998) window.

## Design workflow

Target spectra can be ASCE 7 two-parameter spectra (also the form of Thai DPT 1301/1302 outside the Bangkok basin) or Eurocode 8 Type 1 and 2 spectra for ground types A–E, and an input record can be scaled to a target over a period range or matched to it in the frequency domain. A suite runs several motions, optionally on profiles randomised with the Toro (1995) model and its generic site-class parameters, and reports the lognormal median and σln of surface spectra, spectral ratios, peak acceleration and peak strain. Post-processing gives the displacement profile, the seismic coefficient $k(t)=\tau/\sigma_v$ of the soil above any layer with its Newmark sliding displacement for a yield coefficient (the dam and landfill outputs of D-MOD2000), and liquefaction triggering by Boulanger & Idriss (2014) from the computed cyclic stress ratio and each layer's $(N_1)_{60cs}$. Extra output depths, undo and redo complete the workflow.

## Agents and MCP

Motus is an agentic application: every action an engineer can take in the window is also an MCP tool, and two kinds of agent use the same tools. The agent inside the window (the bot button in the tool strip) is an LLM that plans its own steps. Its thread is an MCP client of the window that opens the session with `initialize`, reads `tools/list` and runs each step as `tools/call` through the in-process handler, so every change appears on screen as it happens. It works with any OpenAI-compatible chat-completions service, with OpenRouter as the default, and keeps its key in the settings folder with owner-only permissions (`OPENROUTER_API_KEY` or `OPENAI_API_KEY` also work). Agents outside the window reach the same handler over MCP Streamable HTTP at `http://127.0.0.1:7879/mcp` (`MOTUS_MCP_PORT` changes the port), or through `motus --mcp`, a stdio bridge that forwards each call to the running window and starts it when needed:

```sh
claude mcp add motus -- /path/to/motus --mcp
```

The listener accepts local connections only and refuses requests from web pages. "Allow outside agents" in the agent settings switches outside access off while the agent inside keeps working. The 26 tools cover the project file, layers and curves, site and bedrock, the input motion (generate, load, scale), analysis settings, `run_analysis` (which answers with a per-layer summary once the background solve ends), `get_results` (profiles, spectra, histories, loops and transfer ratios), `show` to put a view on screen, `screenshot` and CSV export.

## Verification

`cargo test -p motus_core --release` runs 14 checks in under a second. The linear transfer function of a uniform damped layer matches the closed form 1/|cos k*H + iα* sin k*H| to 10⁻⁶ for both base conditions, and the time-domain solver with elastic curves reproduces the frequency-domain spectra within 10 % from 0.05 to 2 s. The Nigam-Jennings spectrum agrees with a brute-force Newmark integration on a 50× finer grid within 1 %, and the numerical Masing damping of a hyperbola matches its closed form within 10⁻⁴. Symmetric Masing loops close exactly and dissipate F times the Masing energy, an inner loop rejoins the backbone through the memory rule, and Darendeli's curve gives γr = 0.0352 % and Dmin = 0.80 % at σ'm = 1 atm for PI = 0. The dissipation solver reproduces Terzaghi's average degree of consolidation within 0.01 at Tv = 0.05, 0.2 and 0.8 for single drainage and at Tv = 0.05 for double drainage, and the clay index follows δ = N^(−t) exactly under uniform cycles. A run of the example shows that the clay degrades, that undrained pore pressure never falls, and that a pervious column with a drained base keeps peak ru lower and dissipates it after shaking. `cargo test -p motus` drives the window headlessly with egui_kittest. One of these tests runs the agent inside against a scripted stand-in for the chat service and checks that its tool calls change the project, run the solver and reach the model as tool results, and another checks the MCP handshake, the HTTP transport and the outside-access switch.

These tests verify the implementation against itself and against closed forms. They are not a validation against D-MOD2000, SHAKE2000, DEEPSOIL or recorded downhole data, which still has to be done before the program is used for design.

## Building and running

```sh
cargo build --release
./target/release/motus                       # window, opens the example site
./target/release/motus examples/example.motus  # open a project
./target/release/motus --run examples/example.motus nl out/   # solve without the window, write CSV
```

Projects are JSON files (`.motus`) that hold the profile, the motion and the settings. File ▸ Export Results writes the profile maxima, PGA with depth, output accelerations, response spectra and stress-strain histories as CSV. `MOTUS_SHOT=out.png` makes the window capture itself and quit, and `MOTUS_PAGE`, `MOTUS_VIEW`, `MOTUS_RUN` and `MOTUS_LAYER` set up the capture.

## Example site

The built-in example follows the layer sequence of the D-MOD2000 tutorial column (sand fill, gravel with sand, PI 35 silty clay and two silty fine sands over rock), but its shear-wave velocities are assumed and the input is a synthetic M 6.5 record at 20 km. With that record the surface PGA is 0.19 g linear, 0.17 g equivalent linear and 0.12 g nonlinear. The nonlinear run carries more energy between 5 and 35 Hz, whereas at the site period near 0.5 s its response is lower because each strong cycle mobilises its own strain and damping rather than a single effective strain.

## Licences

The code is MIT OR Apache-2.0. The Motus icon and logo were drawn with gpt-image-2 (sources and prompts in `brand/`). The interface theme and widgets are ported from PhotoCraft (MIT OR Apache-2.0), the icons are Lucide (ISC), and the Inter font is under the SIL Open Font License (`app/assets/fonts/OFL-Inter.txt`).
